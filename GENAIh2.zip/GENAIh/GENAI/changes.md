# Changes Made During This Chat

This log covers the Driver, Owner, Customer, and ResiliRoute updates made during this chat.

## Driver Route Assistant

- Replaced fixed sample map markers with a driving route drawn between the selected locations, including start and destination markers.
- Added destination weather, distance, driving duration, departure date and time, planned break, and estimated arrival.
- Added location suggestions and clearer loading/error messages.
- Kept Ollama driving tips optional. Route planning, map display, weather, and timing do not depend on Ollama.
- Uses Open-Meteo for location search and weather, OSRM for driving routes, and Leaflet/OpenStreetMap for the map.

## Transporter / Owner Dashboard

- Added truck type, quantity, location, and status inputs with dropdowns and basic validation.
- Added a fleet inventory with total, idle, active, and maintenance counts.
- Added status filtering, status updates, and removal for fleet entries.
- Saves the fleet inventory in the current browser using local storage; it is not sent to the backend.
- Updated fleet analysis prompts to use the listed truck status and locations.

## Customer Load Booking

- Added load type, pickup date, delivery priority, and handling selections, plus city suggestions and weight validation.
- Added an indicative truck estimate with an explicit note that it is not a confirmed quote or booking.
- Temperature-controlled shipments recommend a refrigerated van.
- Added local draft requests with route, load, pickup date, priority, handling, truck, and estimate details.
- Added recent-draft display, individual removal, and clear-all controls. Drafts are stored in the current browser only and are not submitted to a carrier or backend.
- Made optional Ollama tips non-blocking, so an unavailable AI service does not prevent the estimate or draft saving.

## ResiliRoute Disaster Logistics Center

- Added a unified command center with Admin, Driver, and Field Officer views and a live operations map.
- Added persistent SQLite records for hazards, geo-tagged field reports, fleet GPS pings, and dispatch alerts.
- Added hazard registration and closure, including severity, road location, and optional bridge weight limits.
- Added IMD district warning feed integration and optional ISRO Bhuvan Northeast landslide susceptibility layers.
- Added route alternatives from OSRM and route risk scoring against active hazards and bridge limits using cargo weight and delivery priority.
- Added GPS ping capture from the device and fleet locations on the map.
- Added field reports with photo uploads, location capture, offline IndexedDB queueing, background sync, and server-side report storage.
- Added browser voice announcements in multiple Indian languages and optional Twilio SMS delivery through environment-configured credentials.
- Added SQLite sync endpoints and an offline app shell with a service worker.
- Added the ResiliRoute entry to the home page and shared navigation. The Flask app now serves the frontend pages and API together.
- Added an incident dispatch board where admins assign work to a vehicle or team and update incidents through Assigned, In progress, and Resolved.
- Added driver geofence warnings for active hazards and blocked roads within 10 km of the vehicle's latest shared GPS position.
- Added field-officer road status reporting for Open, Blocked, and Cleared roads. Blocked road updates are included in route risk scoring, and later updates for the same named road clear its prior blocked state.
- Added an evacuation planner backed by an admin-maintained directory of shelters, hospitals, and relief centers. It filters open destinations, calculates drivable routes, ranks them by reported hazard risk and travel time, and can display a selected route on the map.

Run the integrated application from the project root with `python frontend/app.py`.

## Files Updated

- `frontend/Driver-interface.html`
- `frontend/driver interface.js`
- `frontend/driver.css`
- `frontend/Owener interface.html`
- `frontend/owner.js`
- `frontend/owner.css`
- `frontend/customer-interface.html`
- `frontend/customer interface.js`
- `frontend/customer interface.css`
- `frontend/resiliroute.html`
- `frontend/resiliroute.css`
- `frontend/resiliroute.js`
- `frontend/resiliroute-sw.js`
- `frontend/resiliroute.html`
- `frontend/resiliroute.css`
- `frontend/resiliroute.js`
- `backend/resiliroute.py`
- `changes.md`
- `frontend/menu.js`
- `frontend/home.html`
- `frontend/home.css`
- `frontend/app.py`
- `backend/app.py`
- `backend/resiliroute.py`
