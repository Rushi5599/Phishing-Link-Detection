"""Convenience launcher for the Flask API and frontend pages."""
import os
import sys


BACKEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend"))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

os.chdir(BACKEND_DIR)
from app import app


if __name__ == "__main__":
    app.run(debug=True)
