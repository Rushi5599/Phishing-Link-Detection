const DRAFT_STORAGE_KEY = "rolex-customer-drafts-v1";
const loadType = document.getElementById("loadType");
const weight = document.getElementById("weight");
const fromCity = document.getElementById("fromCity");
const toCity = document.getElementById("toCity");
const truck1 = document.getElementById("truck1");
const truck2 = document.getElementById("truck2");
const truck3 = document.getElementById("truck3");
const cost1 = document.getElementById("cost1");
const cost2 = document.getElementById("cost2");
const cost3 = document.getElementById("cost3");
const reason1 = document.getElementById("reason1");
const reason2 = document.getElementById("reason2");
const reason3 = document.getElementById("reason3");
const aiBox = document.getElementById("aiBox");
const forecastBox = document.getElementById("forecastBox");
const forecastRoute = document.getElementById("forecastRoute");
const forecastLevel = document.getElementById("forecastLevel");
const forecastConfidence = document.getElementById("forecastConfidence");
const forecastAI = document.getElementById("forecastAI");
let currentEstimate = null;
let estimateVersion = 0;
let savedDrafts = loadSavedDrafts();

const trucks = [
  { type: "Mini Truck", loads: ["general", "electronics"], reason: "Best for light loads and short to medium distance transport." },
  { type: "Pickup Van", loads: ["food", "furniture"], reason: "Suitable for bulky items with balanced cost and capacity." },
  { type: "Refrigerated Van", loads: ["medicine", "medical", "pharma"], reason: "Maintains temperature safety for medical goods." }
];

const demandData = [
  { from: "pune", to: "mumbai", level: "High", confidence: "85%", reason: "Strong industrial trade, daily freight movement, and return-load availability." },
  { from: "pune", to: "nanded", level: "Medium", confidence: "70%", reason: "Agriculture supply, fertilizers, and regional wholesale transport." }
];

document.getElementById("bookingForm").addEventListener("submit", getRecommendation);
document.getElementById("saveDraftButton").addEventListener("click", saveCurrentDraft);
document.getElementById("clearDraftsButton").addEventListener("click", clearSavedDrafts);
document.getElementById("savedBookingsList").addEventListener("click", event => {
  const button = event.target.closest("[data-delete-draft]");
  if (!button) return;
  savedDrafts = savedDrafts.filter(draft => draft.id !== button.dataset.deleteDraft);
  persistDrafts();
  renderSavedDrafts();
});

const pickupDate = document.getElementById("pickupDate");
const today = new Date();
const localToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
pickupDate.min = localToday;
pickupDate.value = localToday;
renderSavedDrafts();

function getRecommendation(event) {
  event.preventDefault();

  const load = loadType.value;
  const weightVal = Number(weight.value);
  const from = fromCity.value.trim();
  const to = toCity.value.trim();
  const handling = document.getElementById("handlingNeeds").value;
  const priority = document.getElementById("deliveryPriority").value;
  const pickup = pickupDate.value;
  if (!load || !Number.isFinite(weightVal) || weightVal <= 0 || !from || !to || !pickup) return;

  const bestTruck = handling === "Temperature controlled"
    ? trucks[2]
    : trucks.find(truck => truck.loads.includes(load)) || trucks[0];
  const baseCost = Math.round(5000 + weightVal * 1200);
  currentEstimate = {
    load,
    loadLabel: loadType.options[loadType.selectedIndex].text,
    weight: weightVal,
    from,
    to,
    pickup,
    priority,
    handling,
    truck: bestTruck.type,
    estimate: baseCost
  };

  truck1.textContent = bestTruck.type;
  cost1.textContent = formatRupees(baseCost);
  const truckReason = `${bestTruck.reason} ${handling === "Temperature controlled" ? "Selected to match temperature-controlled handling." : ""}`.trim();
  reason1.textContent = truckReason;
  truck2.textContent = "Pickup Van";
  cost2.textContent = formatRupees(baseCost + 2000);
  reason2.textContent = "Alternative estimate; confirm vehicle suitability before booking.";
  truck3.textContent = "Refrigerated Van";
  cost3.textContent = formatRupees(baseCost + 4000);
  reason3.textContent = "Consider for temperature-sensitive goods.";

  aiBox.style.display = "block";
  document.getElementById("saveDraftButton").disabled = false;
  document.getElementById("saveDraftButton").textContent = "Save draft request";
  document.getElementById("bookingStatus").textContent = "Estimate ready. Save it as a local draft request to review later.";
  const requestVersion = ++estimateVersion;
  reason1.textContent = `${truckReason}\n\nOptional AI tips are loading…`;
  ollamaAISuggestion(currentEstimate).then(aiTip => {
    if (requestVersion === estimateVersion) reason1.textContent = `${truckReason}\n\nAI tip: ${aiTip}`;
  });

  const forecast = demandData.find(item => item.from === from.toLowerCase() && item.to === to.toLowerCase()) || {
    level: "Medium",
    confidence: "60%",
    reason: "General inter-city transport demand based on similar routes."
  };
  forecastRoute.textContent = `${from} → ${to}`;
  forecastLevel.textContent = forecast.level;
  forecastConfidence.textContent = forecast.confidence;
  forecastAI.textContent = `${forecast.reason} Forecast is derived from historical movement patterns.`;
  forecastBox.style.display = "block";
}

async function ollamaAISuggestion(estimate) {
  try {
    const res = await fetch("http://localhost:11434/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "llama3",
        prompt: `You are a logistics AI. Give 3 concise, practical tips for transporting ${estimate.weight} tonnes of ${estimate.loadLabel} from ${estimate.from} to ${estimate.to} for pickup on ${estimate.pickup}. Priority: ${estimate.priority}. Handling: ${estimate.handling}. Do not claim this is a confirmed booking.`,
        stream: false,
        options: { num_predict: 160 }
      })
    });
    if (!res.ok) throw new Error("AI service unavailable");
    const data = await res.json();
    return data.response || "No AI tip was returned.";
  } catch {
    return "Optional AI tips are unavailable; the estimate and draft saving still work.";
  }
}

function saveCurrentDraft() {
  if (!currentEstimate) return;
  savedDrafts.unshift({
    ...currentEstimate,
    id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString()
  });
  const saved = persistDrafts();
  renderSavedDrafts();
  const button = document.getElementById("saveDraftButton");
  button.disabled = true;
  button.textContent = "Draft saved";
  document.getElementById("bookingStatus").textContent = saved
    ? "Draft saved in this browser. No booking was submitted."
    : "Draft is available until this page closes, but browser storage is unavailable.";
}

function loadSavedDrafts() {
  try {
    const drafts = JSON.parse(localStorage.getItem(DRAFT_STORAGE_KEY) || "[]");
    return Array.isArray(drafts) ? drafts.filter(draft => draft && typeof draft.id === "string" && typeof draft.from === "string" && typeof draft.to === "string") : [];
  } catch {
    return [];
  }
}

function persistDrafts() {
  try {
    localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(savedDrafts));
    return true;
  } catch {
    return false;
  }
}

function renderSavedDrafts() {
  const list = document.getElementById("savedBookingsList");
  const clearButton = document.getElementById("clearDraftsButton");
  clearButton.hidden = savedDrafts.length === 0;
  if (!savedDrafts.length) {
    list.innerHTML = '<p class="empty-drafts">No saved drafts yet. Create an estimate and choose “Save draft request”.</p>';
    return;
  }

  list.innerHTML = savedDrafts.map(draft => `
    <article class="saved-booking-card">
      <div class="saved-booking-main">
        <strong>${escapeHtml(draft.from)} → ${escapeHtml(draft.to)}</strong>
        <span>${escapeHtml(draft.loadLabel || draft.load)} · ${escapeHtml(draft.weight)} tonnes · ${escapeHtml(draft.truck)}</span>
      </div>
      <div class="saved-booking-details">
        <span>Pickup: ${escapeHtml(formatDate(draft.pickup))}</span>
        <span>${escapeHtml(draft.priority)} · ${escapeHtml(draft.handling)}</span>
        <strong>${formatRupees(Number(draft.estimate))} est.</strong>
      </div>
      <div class="saved-booking-actions">
        <span class="draft-badge">Draft · local only</span>
        <button type="button" data-delete-draft="${escapeHtml(draft.id)}" aria-label="Remove draft for ${escapeHtml(draft.from)} to ${escapeHtml(draft.to)}">Remove</button>
      </div>
    </article>
  `).join("");
}

function clearSavedDrafts() {
  savedDrafts = [];
  persistDrafts();
  renderSavedDrafts();
}

function formatRupees(amount) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);
}

function formatDate(dateValue) {
  if (!dateValue) return "Not set";
  const date = new Date(`${dateValue}T00:00:00`);
  return Number.isNaN(date.getTime()) ? "Not set" : new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}
