const SHELL_CACHE = "resiliroute-shell-v2";
const LIBRARY_CACHE = "resiliroute-libraries-v1";
const APP_SHELL = [
  "/resiliroute",
  "/resiliroute.html",
  "/resiliroute.css",
  "/resiliroute.js",
  "/global.css",
  "/menu.js",
  "/home.html"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(SHELL_CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith("resiliroute-") && ![SHELL_CACHE, LIBRARY_CACHE].includes(key))
    .map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin && !url.hostname.endsWith("unpkg.com")) return;
  if (url.pathname.startsWith("/api/")) return;

  if (url.hostname.endsWith("unpkg.com")) {
    event.respondWith(caches.open(LIBRARY_CACHE).then(async cache => {
      const cached = await cache.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response.ok || response.type === "opaque") cache.put(request, response.clone());
      return response;
    }).catch(() => caches.match(request)));
    return;
  }

  event.respondWith(fetch(request).then(response => {
    if (response.ok) caches.open(SHELL_CACHE).then(cache => cache.put(request, response.clone()));
    return response;
  }).catch(async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    if (request.mode === "navigate") return caches.match("/resiliroute");
    return Response.error();
  }));
});

self.addEventListener("sync", event => {
  if (event.tag === "resiliroute-offline-sync") {
    event.waitUntil(syncQueuedData().then(() => notifyClients()));
  }
});

async function openQueueDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("resiliroute-offline-v1", 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("reports")) db.createObjectStore("reports", { keyPath: "id" });
      if (!db.objectStoreNames.contains("pings")) db.createObjectStore("pings", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function readAll(storeName) {
  const db = await openQueueDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readonly");
    const request = transaction.objectStore(storeName).getAll();
    request.onsuccess = () => { db.close(); resolve(request.result); };
    request.onerror = () => { db.close(); reject(request.error); };
  });
}

async function removeItem(storeName, id) {
  const db = await openQueueDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).delete(id);
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}

async function syncQueuedData() {
  const reports = await readAll("reports");
  for (const report of reports) {
    const form = new FormData();
    Object.entries(report).forEach(([key, value]) => {
      if (key === "photo") { if (value) form.append("photo", value, value.name || "field-report.jpg"); }
      else form.append(key, value);
    });
    const response = await fetch("/api/resiliroute/reports", { method: "POST", body: form });
    if (response.ok) await removeItem("reports", report.id);
  }

  const pings = await readAll("pings");
  if (pings.length) {
    const response = await fetch("/api/resiliroute/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pings })
    });
    if (response.ok) {
      const result = await response.json();
      if (!result.errors?.length) await Promise.all(pings.map(ping => removeItem("pings", ping.id)));
    }
  }
}

async function notifyClients() {
  const clients = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
  clients.forEach(client => client.postMessage({ type: "sync-complete" }));
}
