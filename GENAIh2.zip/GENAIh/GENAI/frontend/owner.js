const OLLAMA_API = "http://localhost:11434/api/generate";
const FLEET_STORAGE_KEY = "rolex-transport-fleet-v1";
let trucks = loadFleet();

document.getElementById("fleetForm").addEventListener("submit", event => {
  event.preventDefault();
  addTruck();
});
document.getElementById("fleetFilter").addEventListener("change", renderFleet);
document.getElementById("truckList").addEventListener("change", event => {
  const select = event.target.closest("[data-status-id]");
  if (!select) return;
  const truck = trucks.find(item => item.id === select.dataset.statusId);
  if (!truck) return;
  truck.status = select.value;
  saveFleet();
  renderFleet();
});
document.getElementById("truckList").addEventListener("click", event => {
  const button = event.target.closest("[data-remove-id]");
  if (!button) return;
  trucks = trucks.filter(item => item.id !== button.dataset.removeId);
  saveFleet();
  renderFleet();
});

function loadFleet() {
  try {
    const saved = JSON.parse(localStorage.getItem(FLEET_STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved.filter(item =>
      item && typeof item.type === "string" && Number.isFinite(Number(item.count)) &&
      typeof item.location === "string" && ["Idle", "Active", "Maintenance"].includes(item.status)
    ) : [];
  } catch {
    return [];
  }
}

function saveFleet() {
  try {
    localStorage.setItem(FLEET_STORAGE_KEY, JSON.stringify(trucks));
  } catch {
    // The current page remains usable if browser storage is unavailable.
  }
}

function addTruck() {
  const type = document.getElementById("truckType").value;
  const count = Number(document.getElementById("truckCount").value);
  const location = document.getElementById("fleetLocation").value.trim();
  const status = document.getElementById("fleetStatus").value;
  if (!type || !Number.isInteger(count) || count < 1 || !location) return;

  trucks.push({
    id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    type,
    count,
    location,
    status
  });
  saveFleet();
  renderFleet();
  document.getElementById("fleetForm").reset();
  document.getElementById("truckType").focus();
}

function renderFleet() {
  const filter = document.getElementById("fleetFilter").value;
  const visibleTrucks = filter === "All" ? trucks : trucks.filter(item => item.status === filter);
  const truckCountByStatus = status => trucks
    .filter(item => item.status === status)
    .reduce((sum, item) => sum + Number(item.count), 0);
  const total = trucks.reduce((sum, item) => sum + Number(item.count), 0);

  document.getElementById("totalTrucks").textContent = total;
  document.getElementById("idleTrucks").textContent = truckCountByStatus("Idle");
  document.getElementById("activeTrucks").textContent = truckCountByStatus("Active");
  document.getElementById("maintenanceTrucks").textContent = truckCountByStatus("Maintenance");

  const list = document.getElementById("truckList");
  if (!visibleTrucks.length) {
    list.innerHTML = `<p class="fleet-empty">${trucks.length ? "No trucks match this status." : "Your fleet is empty. Add a truck group above to start tracking availability."}</p>`;
    return;
  }

  list.innerHTML = visibleTrucks.map(truck => `
    <article class="fleet-row">
      <div class="fleet-vehicle">
        <strong>${escapeHtml(truck.type)}</strong>
        <span>${Number(truck.count)} truck${Number(truck.count) === 1 ? "" : "s"} · ${escapeHtml(truck.location)}</span>
      </div>
      <label class="fleet-status-control">
        <span>Status</span>
        <select data-status-id="${escapeHtml(truck.id)}" aria-label="Status for ${escapeHtml(truck.type)}">
          ${["Idle", "Active", "Maintenance"].map(status => `<option${truck.status === status ? " selected" : ""}>${status}</option>`).join("")}
        </select>
      </label>
      <button class="remove-truck" type="button" data-remove-id="${escapeHtml(truck.id)}" aria-label="Remove ${escapeHtml(truck.type)}">Remove</button>
    </article>
  `).join("");
}

async function analyzeFleet() {
  if (!trucks.length) {
    document.getElementById("result").innerText = "Add fleet details first to get a useful utilization analysis.";
    return;
  }

  const fleet = trucks.map(t => `${t.type} - ${t.count} trucks, ${t.status}, ${t.location}`).join("\n");
  const prompt = `You are a fleet management AI in India.\nFleet:\n${fleet}\n\nGive practical utilization tips, idle truck advice, and demand suggestions.`;
  document.getElementById("result").innerText = await askAI(prompt);
}

async function analyzeProfit() {
  if (!trucks.length) {
    document.getElementById("result").innerText = "Add fleet details first to get a useful profit analysis.";
    return;
  }

  const fleet = trucks.map(t => `${t.type} - ${t.count} (${t.status})`).join(", ");
  const prompt = `Analyze profit opportunities for an Indian transport owner.\nFleet: ${fleet}\nGive practical route ideas, seasonal opportunities, and cost-saving tips.`;
  document.getElementById("result").innerText = await askAI(prompt);
}

async function analyzeGoods() {
  const season = document.getElementById("seasonSelect").value;
  if (!season) return alert("Select season");

  const prompt = `Season: ${season}\nSuggest high-demand goods, suitable truck types, and one practical business tip.`;
  document.getElementById("goodsResult").innerText = await askAI(prompt);
}

async function askAI(prompt) {
  try {
    const res = await fetch(OLLAMA_API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "phi", prompt, stream: false, options: { num_predict: 250 } })
    });
    if (!res.ok) throw new Error("Ollama returned an error.");
    const data = await res.json();
    return data.response || "AI response unavailable.";
  } catch {
    return "⚠️ Ollama is unavailable. Your fleet inventory remains saved in this browser.";
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

renderFleet();
