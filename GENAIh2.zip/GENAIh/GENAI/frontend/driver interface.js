const OLLAMA_API = "http://localhost:11434/api/generate";
const GEOCODING_API = "https://geocoding-api.open-meteo.com/v1/search";
const OSRM_API = "https://router.project-osrm.org/route/v1/driving";
const OPEN_METEO_API = "https://api.open-meteo.com/v1/forecast";

let map;
let routeLayer;
let routeMarkers = [];
let currentRoute = null;

document.addEventListener("DOMContentLoaded", () => {
  map = L.map("map").setView([22.5, 79], 4);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors",
    maxZoom: 19
  }).addTo(map);

  document.getElementById("routeForm").addEventListener("submit", planRoute);
  document.getElementById("aiButton").addEventListener("click", generateAiTips);
  document.getElementById("departureTime").addEventListener("change", updateArrival);
  document.getElementById("breakDuration").addEventListener("change", updateArrival);
  setTimeout(() => map.invalidateSize(), 250);
});

async function planRoute(event) {
  event.preventDefault();

  const fromName = document.getElementById("fromCity").value.trim();
  const toName = document.getElementById("toCity").value.trim();
  if (!fromName || !toName) return;

  const button = document.getElementById("routeButton");
  const status = document.getElementById("routeStatus");
  button.disabled = true;
  button.textContent = "Finding route…";
  status.textContent = "Finding both locations and calculating the driving route…";
  currentRoute = null;
  document.getElementById("routeOverview").hidden = true;
  document.getElementById("weatherBox").hidden = true;
  if (routeLayer) {
    map.removeLayer(routeLayer);
    routeLayer = null;
  }
  routeMarkers.forEach(marker => map.removeLayer(marker));
  routeMarkers = [];

  try {
    const from = await geocodeCity(fromName);
    const to = await geocodeCity(toName);
    const routeUrl = `${OSRM_API}/${from.lon},${from.lat};${to.lon},${to.lat}?overview=full&geometries=geojson&steps=false`;
    const routeResponse = await fetch(routeUrl);
    if (!routeResponse.ok) throw new Error("The route service is unavailable right now.");

    const routeData = await routeResponse.json();
    const route = routeData.routes && routeData.routes[0];
    if (!route) throw new Error("No driving route was found for those locations.");

    currentRoute = { from, to, route };
    drawRoute(from, to, route.geometry);
    document.getElementById("routeOverview").hidden = false;
    document.getElementById("distanceValue").textContent = `${(route.distance / 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })} km`;
    document.getElementById("durationValue").textContent = formatDuration(route.duration);
    updateArrival();
    status.textContent = `Route found: ${from.name} to ${to.name}.`;
    document.getElementById("weatherBox").hidden = false;
    loadDestinationWeather(to).catch(showWeatherError);
  } catch (error) {
    status.textContent = error.message || "Could not calculate the route. Please try again.";
  } finally {
    button.disabled = false;
    button.textContent = "Get best route";
  }
}

async function geocodeCity(query) {
  const params = new URLSearchParams({ name: query, count: "1", language: "en", countryCode: "IN" });
  const response = await fetch(`${GEOCODING_API}?${params}`);
  if (!response.ok) throw new Error("Location search is temporarily unavailable. Please try again.");

  const results = await response.json();
  if (!results.results || !results.results.length) throw new Error(`Could not find “${query}”. Try adding its state.`);
  const place = results.results[0];

  return {
    lat: place.latitude,
    lon: place.longitude,
    name: [place.name, place.admin1].filter(Boolean).join(", ")
  };
}

function drawRoute(from, to, geometry) {
  if (routeLayer) map.removeLayer(routeLayer);
  routeMarkers.forEach(marker => map.removeLayer(marker));
  routeMarkers = [];

  routeLayer = L.geoJSON(geometry, {
    style: { color: "#1769d2", weight: 6, opacity: 0.85 }
  }).addTo(map);

  routeMarkers.push(
    L.marker([from.lat, from.lon]).addTo(map).bindPopup(`<strong>Start</strong><br>${escapeHtml(from.name)}`),
    L.marker([to.lat, to.lon]).addTo(map).bindPopup(`<strong>Destination</strong><br>${escapeHtml(to.name)}`)
  );
  map.fitBounds(routeLayer.getBounds(), { padding: [28, 28] });
}

async function loadDestinationWeather(destination) {
  const params = new URLSearchParams({
    latitude: destination.lat,
    longitude: destination.lon,
    current: "temperature_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m",
    timezone: "auto"
  });
  const response = await fetch(`${OPEN_METEO_API}?${params}`);
  if (!response.ok) throw new Error("Weather data is unavailable right now.");

  const data = await response.json();
  if (!data.current) throw new Error("Weather data is unavailable right now.");

  const current = data.current;
  document.getElementById("weatherLocation").textContent = destination.name;
  document.getElementById("weatherDescription").textContent = weatherDescription(current.weather_code);
  document.getElementById("weatherTemperature").textContent = `${Math.round(current.temperature_2m)}°C`;
  document.getElementById("weatherWind").textContent = `${Math.round(current.wind_speed_10m)} km/h`;
  document.getElementById("weatherRain").textContent = `${current.precipitation} mm`;
}

function showWeatherError(error) {
  document.getElementById("weatherLocation").textContent = "Destination weather";
  document.getElementById("weatherDescription").textContent = error.message || "Weather data is unavailable right now.";
  document.getElementById("weatherTemperature").textContent = "—";
  document.getElementById("weatherWind").textContent = "—";
  document.getElementById("weatherRain").textContent = "—";
}

function updateArrival() {
  if (!currentRoute) return;
  const departureInput = document.getElementById("departureTime").value;
  const departure = departureInput ? new Date(departureInput) : new Date();
  const breakMinutes = Number(document.getElementById("breakDuration").value) || 0;
  const arrival = new Date(departure.getTime() + (currentRoute.route.duration + breakMinutes * 60) * 1000);
  document.getElementById("arrivalValue").textContent = new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(arrival);
}

function formatDuration(seconds) {
  const minutes = Math.round(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  if (hours === 0) return `${remainder} min`;
  return remainder ? `${hours} hr ${remainder} min` : `${hours} hr`;
}

function weatherDescription(code) {
  if (code === 0) return "Clear sky";
  if ([1, 2, 3].includes(code)) return "Mainly clear to overcast";
  if ([45, 48].includes(code)) return "Foggy conditions";
  if ([51, 53, 55, 56, 57].includes(code)) return "Drizzle";
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return "Rain expected";
  if ([71, 73, 75, 77, 85, 86].includes(code)) return "Snowfall";
  if ([95, 96, 99].includes(code)) return "Thunderstorm";
  return "Current conditions";
}

async function generateAiTips() {
  const result = document.getElementById("result");
  if (!currentRoute) {
    result.textContent = "Plan a route first to get location-specific tips.";
    return;
  }

  const button = document.getElementById("aiButton");
  button.disabled = true;
  button.textContent = "Generating…";
  result.textContent = "Asking the local Ollama service for driving tips…";

  const prompt = `You are an Indian logistics driver assistant. Give concise, practical highway, fuel, parking, and rest guidance for a ${formatDuration(currentRoute.route.duration)} trip from ${currentRoute.from.name} to ${currentRoute.to.name}. Estimated distance: ${(currentRoute.route.distance / 1000).toFixed(0)} km. Clearly label general suggestions that should be verified on the road.`;

  try {
    const response = await fetch(OLLAMA_API, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "phi", prompt, stream: false, options: { num_predict: 220 } })
    });
    if (!response.ok) throw new Error("Ollama returned an error.");
    const data = await response.json();
    result.textContent = data.response || "Ollama did not return any tips.";
  } catch (error) {
    result.textContent = "Optional AI tips are unavailable. The route, map, trip time, and weather still work without Ollama.";
  } finally {
    button.disabled = false;
    button.textContent = "Generate AI tips";
  }
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}
