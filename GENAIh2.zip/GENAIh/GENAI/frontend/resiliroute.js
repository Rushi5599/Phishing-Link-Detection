const API = "/api/resiliroute";
const DB_NAME = "resiliroute-offline-v1";
const DB_VERSION = 1;
let map;
let routeLayers = [];
let hazardMarkers = L.layerGroup();
let reportMarkers = L.layerGroup();
let fleetMarkers = L.layerGroup();
let roadStatusMarkers = L.layerGroup();
let activeHazards = [];
let currentRoute = null;

document.addEventListener("DOMContentLoaded", async () => {
  initializeMap();
  document.querySelectorAll(".role-tab").forEach(button => button.addEventListener("click", () => showRole(button.dataset.view)));
  document.getElementById("hazardForm").addEventListener("submit", submitHazard);
  document.getElementById("hazardGpsButton").addEventListener("click", () => fillCoordinates("hazardLat", "hazardLon", "hazardStatus"));
  document.getElementById("reportGpsButton").addEventListener("click", () => fillCoordinates("reportLat", "reportLon", "reportStatus"));
  document.getElementById("reportForm").addEventListener("submit", submitReport);
  document.getElementById("gpsForm").addEventListener("submit", submitGpsPing);
  document.getElementById("routeForm").addEventListener("submit", findSafeRoute);
  document.getElementById("alertForm").addEventListener("submit", submitAlert);
  document.getElementById("incidentForm").addEventListener("submit", submitIncident);
  document.getElementById("incidentGpsButton").addEventListener("click", () => fillCoordinates("incidentLat", "incidentLon", "incidentStatus"));
  document.getElementById("safeSiteForm").addEventListener("submit", submitSafeSite);
  document.getElementById("siteGpsButton").addEventListener("click", () => fillCoordinates("siteLat", "siteLon", "siteStatus"));
  document.getElementById("evacuationForm").addEventListener("submit", planEvacuation);
  document.getElementById("evacGpsButton").addEventListener("click", () => fillCoordinates("evacLat", "evacLon", "evacStatus"));
  document.getElementById("roadStatusForm").addEventListener("submit", submitRoadStatus);
  document.getElementById("roadStatusGpsButton").addEventListener("click", () => fillCoordinates("roadStatusLat", "roadStatusLon", "roadStatusMessage"));
  document.getElementById("refreshMapButton").addEventListener("click", refreshData);
  document.getElementById("refreshWarningsButton").addEventListener("click", loadWeatherWarnings);
  document.getElementById("syncButton").addEventListener("click", syncOfflineQueue);
  document.getElementById("hazardList").addEventListener("click", removeHazard);
  document.getElementById("incidentList").addEventListener("change", updateIncidentStatus);
  document.getElementById("reportPhoto").addEventListener("change", previewPhoto);
  window.addEventListener("online", () => { updateConnectivity(); syncOfflineQueue(); refreshData(); });
  window.addEventListener("offline", updateConnectivity);
  navigator.serviceWorker?.addEventListener("message", event => {
    if (event.data?.type === "sync-complete") syncOfflineQueue();
  });

  updateConnectivity();
  await registerServiceWorker();
  await refreshData();
  await loadWeatherWarnings();
  await renderQueue();
  window.setInterval(refreshData, 30000);
});

function initializeMap() {
  map = L.map("map").setView([26.1, 93.2], 6);
  const street = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors",
    maxZoom: 19
  }).addTo(map);
  const bhuvanUrl = "https://bhuvan-vec2.nrsc.gov.in/bhuvan/wms";
  const stateLayers = [
    "disaster:AS_SLIM_2017", "disaster:AR_SLIM_2017", "disaster:ML_SLIM_2017",
    "disaster:MN_SLIM_2017", "disaster:MZ_SLIM_2017", "disaster:NL_SLIM_2017",
    "disaster:SK_SLIM_2017", "disaster:LS_TRIPURA_2023", "disaster:LS_WESTBENGAL_2023"
  ];
  const bhuvan = L.layerGroup(stateLayers.map(layer => L.tileLayer.wms(bhuvanUrl, {
    layers: layer,
    format: "image/png",
    transparent: true,
    version: "1.1.1",
    opacity: 0.52,
    attribution: "ISRO Bhuvan"
  })));
  hazardMarkers.addTo(map);
  reportMarkers.addTo(map);
  fleetMarkers.addTo(map);
  roadStatusMarkers.addTo(map);
  L.control.layers({ "OpenStreetMap": street }, { "ISRO Bhuvan landslide susceptibility": bhuvan }, { collapsed: true }).addTo(map);
  map.on("click", event => {
    document.getElementById("hazardLat").value = event.latlng.lat.toFixed(6);
    document.getElementById("hazardLon").value = event.latlng.lng.toFixed(6);
  });
  window.setTimeout(() => map.invalidateSize(), 250);
}

function showRole(viewId) {
  document.querySelectorAll(".role-view").forEach(section => { section.hidden = section.id !== viewId; });
  document.querySelectorAll(".role-tab").forEach(button => button.classList.toggle("active", button.dataset.view === viewId));
  window.setTimeout(() => map.invalidateSize(), 100);
}

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

async function refreshData() {
  if (!navigator.onLine) {
    updateConnectivity();
    return;
  }
  try {
    const [overview, hazardData, reportData, fleetData, alertData, incidentData, siteData, roadData] = await Promise.all([
      api("/overview"), api("/hazards"), api("/reports"), api("/fleet"), api("/alerts"), api("/incidents"), api("/safe-sites"), api("/road-status")
    ]);
    activeHazards = hazardData.hazards || [];
    renderStats(overview.counts || {});
    renderHazards(activeHazards);
    renderReports(reportData.reports || []);
    renderFleet(fleetData.fleet || []);
    renderAlerts(alertData.alerts || []);
    renderIncidents(incidentData.incidents || []);
    renderSafeSites(siteData.sites || []);
    renderRoadStatus(roadData.updates || []);
    loadNearbyDriverAlerts();
    renderMap(activeHazards, reportData.reports || [], fleetData.fleet || []);
    document.getElementById("connectivityStatus").textContent = "Online · live sync";
  } catch (error) {
    document.getElementById("connectivityStatus").textContent = "Online · server reconnecting";
    console.error("ResiliRoute refresh failed:", error);
  }
}

function renderStats(counts) {
  document.getElementById("statHazards").textContent = counts.active_hazards ?? 0;
  document.getElementById("statReports").textContent = counts.field_reports ?? 0;
  document.getElementById("statTrucks").textContent = counts.tracked_trucks ?? 0;
  document.getElementById("statAlerts").textContent = counts.alerts_sent ?? 0;
}

function renderMap(hazards, reports, fleet) {
  hazardMarkers.clearLayers();
  reportMarkers.clearLayers();
  fleetMarkers.clearLayers();
  roadStatusMarkers.clearLayers();
  hazards.forEach(hazard => {
    L.circleMarker([hazard.latitude, hazard.longitude], {
      radius: hazard.severity === "Critical" ? 10 : 8,
      color: severityColor(hazard.severity),
      fillColor: severityColor(hazard.severity),
      fillOpacity: 0.8,
      weight: 2
    }).bindPopup(`<strong>${escapeHtml(hazard.title)}</strong><br>${escapeHtml(hazard.hazard_type)} · ${escapeHtml(hazard.severity)}<br>${escapeHtml(hazard.road_name || "Road area not specified")}${hazard.bridge_limit_tons === null ? "" : `<br>Bridge limit: ${escapeHtml(hazard.bridge_limit_tons)} tonnes`}`).addTo(hazardMarkers);
  });
  reports.forEach(report => {
    const marker = L.circleMarker([report.latitude, report.longitude], { radius: 6, color: "#8156a7", fillColor: "#ad86cc", fillOpacity: 0.85 });
    const image = report.photo_url ? `<br><img src="${escapeHtml(report.photo_url)}" alt="Field report photo">` : "";
    marker.bindPopup(`<strong>Field report: ${escapeHtml(report.report_type)}</strong><br>${escapeHtml(report.severity)} · ${escapeHtml(report.location || "Location tagged")}${image}`).addTo(reportMarkers);
  });
  fleet.forEach(truck => {
    L.marker([truck.latitude, truck.longitude]).bindPopup(`<strong>🚚 ${escapeHtml(truck.truck_id)}</strong><br>${escapeHtml(truck.status)} · ${escapeHtml(truck.speed_kmh)} km/h<br>Cargo: ${escapeHtml(truck.cargo_weight_tons)} tonnes`).addTo(fleetMarkers);
  });
  api("/road-status").then(data => (data.updates || []).forEach(update => {
    const color = update.status === "Blocked" ? "#b42332" : update.status === "Cleared" ? "#2b8a62" : "#2877a8";
    L.circleMarker([update.latitude, update.longitude], { radius: 7, color, fillColor: color, fillOpacity: 0.8 })
      .bindPopup(`<strong>${escapeHtml(update.road_name || "Road status")}</strong><br>${escapeHtml(update.status)}<br>${escapeHtml(update.notes || "")}`).addTo(roadStatusMarkers);
  })).catch(() => {});
  if (!currentRoute && hazards.length) {
    const points = hazards.map(hazard => [hazard.latitude, hazard.longitude]);
    map.fitBounds(L.latLngBounds(points).pad(0.18), { maxZoom: 8 });
  }
}

function renderHazards(hazards) {
  const list = document.getElementById("hazardList");
  if (!hazards.length) {
    list.innerHTML = '<p class="record-empty">No active hazard records. Add an observation or receive a field report.</p>';
    return;
  }
  list.innerHTML = hazards.map(hazard => `
    <article class="record-card">
      <div><strong>${escapeHtml(hazard.title)}</strong><p>${escapeHtml(hazard.hazard_type)} · ${escapeHtml(hazard.road_name || "Area not set")}</p><small>${Number(hazard.latitude).toFixed(4)}, ${Number(hazard.longitude).toFixed(4)}${hazard.bridge_limit_tons === null ? "" : ` · ${escapeHtml(hazard.bridge_limit_tons)} t bridge cap`}</small></div>
      <div><span class="severity-pill ${hazard.severity.toLowerCase()}">${escapeHtml(hazard.severity)}</span><br><button type="button" data-close-hazard="${hazard.id}">Mark clear</button></div>
    </article>
  `).join("");
}

function renderReports(reports) {
  const list = document.getElementById("adminReportList");
  if (!reports.length) {
    list.innerHTML = '<p class="record-empty">Field observations will appear here when crews sync their reports.</p>';
    return;
  }
  list.innerHTML = reports.slice(0, 15).map(report => `
    <article class="record-card">
      <div><strong>${escapeHtml(report.report_type)} · ${escapeHtml(report.location || "Geo-tagged report")}</strong><p>${escapeHtml(report.notes || "No additional notes")}</p><small>${new Date(report.created_at).toLocaleString()} · ${Number(report.latitude).toFixed(4)}, ${Number(report.longitude).toFixed(4)}</small>${report.photo_url ? `<a href="${escapeHtml(report.photo_url)}" target="_blank" rel="noreferrer"><img src="${escapeHtml(report.photo_url)}" alt="Field report photo"></a>` : ""}</div>
      <span class="severity-pill ${report.severity.toLowerCase()}">${escapeHtml(report.severity)}</span>
    </article>
  `).join("");
}

function renderFleet(fleet) {
  const list = document.getElementById("fleetList");
  if (!fleet.length) {
    list.innerHTML = '<p class="record-empty">Vehicle GPS pings will appear here.</p>';
    return;
  }
  list.innerHTML = fleet.map(truck => `<article class="record-card"><div><strong>🚚 ${escapeHtml(truck.truck_id)}</strong><p>${escapeHtml(truck.status)} · ${escapeHtml(truck.speed_kmh)} km/h · ${escapeHtml(truck.cargo_weight_tons)} tonnes</p><small>${Number(truck.latitude).toFixed(4)}, ${Number(truck.longitude).toFixed(4)} · ${new Date(truck.updated_at).toLocaleString()}</small></div><button type="button" data-center-lat="${truck.latitude}" data-center-lon="${truck.longitude}">Locate</button></article>`).join("");
  list.querySelectorAll("[data-center-lat]").forEach(button => button.addEventListener("click", () => map.setView([Number(button.dataset.centerLat), Number(button.dataset.centerLon)], 13)));
}

function renderAlerts(alerts) {
  const list = document.getElementById("alertList");
  list.innerHTML = alerts.length ? alerts.slice(0, 5).map(alert => `<article class="record-card"><div><strong>${escapeHtml(alert.target)} · ${escapeHtml(alert.severity)}</strong><p>${escapeHtml(alert.message)}</p><small>${new Date(alert.created_at).toLocaleString()} · ${escapeHtml(alert.channel)} · ${escapeHtml(alert.delivery_status)}</small></div></article>`).join("") : '<p class="record-empty">Dispatched alerts will be listed here.</p>';
}

function renderIncidents(incidents) {
  const list = document.getElementById("incidentList");
  list.innerHTML = incidents.length ? incidents.map(item => `<article class="record-card"><div><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.assignee)} · ${escapeHtml(item.details || "No extra instructions")}</p><small>${Number(item.latitude).toFixed(4)}, ${Number(item.longitude).toFixed(4)} · Updated ${new Date(item.updated_at).toLocaleString()}</small></div><label class="incident-status">Status<select data-incident-id="${escapeHtml(item.id)}"><option ${item.status === "Assigned" ? "selected" : ""}>Assigned</option><option ${item.status === "In progress" ? "selected" : ""}>In progress</option><option ${item.status === "Resolved" ? "selected" : ""}>Resolved</option></select></label></article>`).join("") : '<p class="record-empty">No dispatched incidents yet.</p>';
}

function renderSafeSites(sites) {
  const list = document.getElementById("safeSiteList");
  list.innerHTML = sites.length ? sites.map(site => `<article class="record-card"><div><strong>${escapeHtml(site.name)}</strong><p>${escapeHtml(site.site_type)} · ${escapeHtml(site.availability)}${site.capacity === null ? "" : ` · Capacity ${escapeHtml(site.capacity)}`}</p><small>${Number(site.latitude).toFixed(4)}, ${Number(site.longitude).toFixed(4)}</small></div></article>`).join("") : '<p class="record-empty">Add verified shelters, hospitals, or relief centers to use evacuation planning.</p>';
}

function renderRoadStatus(updates) {
  const list = document.getElementById("roadStatusList");
  list.innerHTML = updates.length ? updates.slice(0, 20).map(item => `<article class="record-card"><div><strong>${escapeHtml(item.road_name || "Unnamed road")}</strong><p>${escapeHtml(item.status)} · ${escapeHtml(item.notes || "No notes")}</p><small>${Number(item.latitude).toFixed(4)}, ${Number(item.longitude).toFixed(4)} · ${new Date(item.updated_at).toLocaleString()}</small></div><span class="severity-pill ${item.status === "Blocked" ? "critical" : "low"}">${escapeHtml(item.status)}</span></article>`).join("") : '<p class="record-empty">No field road status updates received.</p>';
}

async function loadNearbyDriverAlerts() {
  const truckId = document.getElementById("truckId").value.trim();
  if (!truckId || !navigator.onLine) return;
  const container = document.getElementById("driverGeofenceAlerts");
  try {
    const data = await api(`/fleet/nearby-alerts?truck_id=${encodeURIComponent(truckId)}`);
    const alerts = data.alerts || [];
    container.innerHTML = alerts.length ? alerts.map(item => `<article class="record-card geofence-alert"><div><strong>${escapeHtml(item.title)} · ${escapeHtml(item.severity)}</strong><p>${escapeHtml(item.distance_km)} km from ${escapeHtml(truckId)}. Use caution and check with the control room.</p></div><button type="button" data-center-lat="${item.latitude}" data-center-lon="${item.longitude}">View</button></article>`).join("") : '<p class="record-empty">No active hazards within 10 km of the latest vehicle location.</p>';
    container.querySelectorAll("[data-center-lat]").forEach(button => button.addEventListener("click", () => map.setView([Number(button.dataset.centerLat), Number(button.dataset.centerLon)], 13)));
  } catch (error) { container.innerHTML = `<p class="record-empty">${escapeHtml(error.message)}</p>`; }
}

async function submitHazard(event) {
  event.preventDefault();
  const status = document.getElementById("hazardStatus");
  const payload = {
    title: document.getElementById("hazardTitle").value.trim(),
    hazard_type: document.getElementById("hazardType").value,
    severity: document.getElementById("hazardSeverity").value,
    road_name: document.getElementById("hazardRoad").value.trim(),
    latitude: Number(document.getElementById("hazardLat").value),
    longitude: Number(document.getElementById("hazardLon").value),
    bridge_limit_tons: document.getElementById("hazardBridgeLimit").value || null,
    description: document.getElementById("hazardDescription").value.trim()
  };
  try {
    await api("/hazards", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    status.textContent = "Hazard added to the shared register and map.";
    event.target.reset();
    await refreshData();
  } catch (error) { status.textContent = error.message; }
}

async function removeHazard(event) {
  const button = event.target.closest("[data-close-hazard]");
  if (!button) return;
  try {
    await api(`/hazards/${button.dataset.closeHazard}`, { method: "DELETE" });
    await refreshData();
  } catch (error) { document.getElementById("hazardStatus").textContent = error.message; }
}

async function findSafeRoute(event) {
  event.preventDefault();
  const status = document.getElementById("routeStatus");
  const button = document.getElementById("routeButton");
  const result = document.getElementById("routeResult");
  button.disabled = true;
  status.textContent = "Resolving both cities and checking the route against active hazards…";
  result.hidden = true;
  try {
    const from = await geocodeCity(document.getElementById("routeFrom").value.trim());
    const to = await geocodeCity(document.getElementById("routeTo").value.trim());
    const url = `https://router.project-osrm.org/route/v1/driving/${from.longitude},${from.latitude};${to.longitude},${to.latitude}?alternatives=3&steps=true&geometries=geojson&overview=full`;
    const routeResponse = await fetch(url);
    if (!routeResponse.ok) throw new Error("The routing service could not calculate this journey.");
    const routeData = await routeResponse.json();
    if (routeData.code !== "Ok" || !routeData.routes?.length) throw new Error("No drivable route was found for these locations.");
    const cargo = Number(document.getElementById("cargoWeight").value);
    const priority = document.getElementById("routePriority").value;
    const scoreData = await api("/route/score", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cargo_weight_tons: cargo, priority, routes: routeData.routes.map(route => ({ coordinates: sampleCoordinates(route.geometry.coordinates, 100) })) })
    });
    const candidates = routeData.routes.map((route, index) => {
      const score = scoreData.routes[index];
      const travelHours = route.duration / 3600;
      return { route, score, index, rank: score.risk_score + travelHours * (priority === "Urgent" ? 1.8 : 0.45) };
    }).sort((a, b) => a.rank - b.rank);
    const best = candidates[0];
    drawRouteOptions(candidates, best.index);
    currentRoute = best.route;
    const riskLabel = best.score.status;
    const hazards = best.score.nearby_hazards.map(item => item.title).join(", ");
    result.innerHTML = `<strong>${escapeHtml(from.name)} → ${escapeHtml(to.name)}</strong><p>Selected route · ${(best.route.distance / 1000).toFixed(0)} km · ${formatDuration(best.route.duration)} · Risk: ${escapeHtml(riskLabel)}</p>${best.score.bridge_restrictions.length ? `<p class="route-warning">Bridge limit conflict: ${best.score.bridge_restrictions.map(item => `${escapeHtml(item.title)} (${escapeHtml(item.limit_tons)} t limit)`).join(", ")}</p>` : ""}${hazards ? `<p>Nearby hazards: ${escapeHtml(hazards)}</p>` : "<p>No active hazard records intersect this route.</p>"}<p>Risk index: ${best.score.risk_score}/100 · Cargo: ${cargo} tonnes · ${priority} priority</p><div>${candidates.map((candidate, number) => `<div class="route-option ${number === 0 ? "selected" : ""}"><strong>${number === 0 ? "Safest available" : `Alternative ${number}`}</strong> · ${(candidate.route.distance / 1000).toFixed(0)} km · ${formatDuration(candidate.route.duration)} · ${candidate.score.status} (${candidate.score.risk_score})</div>`).join("")}</div>`;
    result.hidden = false;
    status.textContent = "Route alternatives scored against the current hazard register and cargo weight.";
  } catch (error) {
    status.textContent = error.message || "Could not calculate a safe route.";
  } finally { button.disabled = false; }
}

async function geocodeCity(query) {
  const params = new URLSearchParams({ name: query, count: "1", language: "en" });
  const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${params}`);
  if (!response.ok) throw new Error("Location search is temporarily unavailable.");
  const data = await response.json();
  if (!data.results?.length) throw new Error(`Could not find “${query}”. Try adding the state.`);
  const place = data.results[0];
  return { latitude: place.latitude, longitude: place.longitude, name: [place.name, place.admin1].filter(Boolean).join(", ") };
}

function drawRouteOptions(candidates, selectedOriginalIndex) {
  routeLayers.forEach(layer => map.removeLayer(layer));
  routeLayers = [];
  candidates.forEach(candidate => {
    const selected = candidate.index === selectedOriginalIndex;
    const line = L.geoJSON(candidate.route.geometry, { style: { color: selected ? "#096a83" : "#73889b", weight: selected ? 7 : 4, opacity: selected ? 0.9 : 0.45, dashArray: selected ? null : "7 7" } }).addTo(map);
    routeLayers.push(line);
  });
  const selected = routeLayers[candidates.findIndex(candidate => candidate.index === selectedOriginalIndex)];
  if (selected) map.fitBounds(selected.getBounds(), { padding: [25, 25] });
}

async function submitReport(event) {
  event.preventDefault();
  const photo = document.getElementById("reportPhoto").files[0] || null;
  if (photo && photo.size > 8 * 1024 * 1024) {
    document.getElementById("reportStatus").textContent = "Choose a photo smaller than 8 MB.";
    return;
  }
  const report = {
    id: crypto.randomUUID(),
    report_type: document.getElementById("reportType").value,
    severity: document.getElementById("reportSeverity").value,
    latitude: Number(document.getElementById("reportLat").value),
    longitude: Number(document.getElementById("reportLon").value),
    location: document.getElementById("reportLocation").value.trim(),
    notes: document.getElementById("reportNotes").value.trim(),
    created_at: new Date().toISOString(),
    photo
  };
  if (!navigator.onLine || !await sendReport(report)) {
    try {
      await putOffline("reports", report);
      document.getElementById("reportStatus").textContent = "Report saved to the offline queue and will sync after reconnection.";
      scheduleBackgroundSync();
    } catch (error) {
      document.getElementById("reportStatus").textContent = `Could not save the report offline: ${error.message}`;
      return;
    }
  } else {
    document.getElementById("reportStatus").textContent = "Field report synced to the operations register.";
  }
  event.target.reset();
  document.getElementById("photoPreview").hidden = true;
  await renderQueue();
  if (navigator.onLine) await refreshData();
}

async function sendReport(report) {
  if (!navigator.onLine) return false;
  try {
    const form = new FormData();
    Object.entries(report).forEach(([key, value]) => {
      if (key === "photo") { if (value) form.append("photo", value, value.name || "field-report.jpg"); }
      else form.append(key, value);
    });
    await api("/reports", { method: "POST", body: form });
    return true;
  } catch { return false; }
}

async function submitGpsPing(event) {
  event.preventDefault();
  const status = document.getElementById("gpsStatus");
  status.textContent = "Getting the device location…";
  try {
    const position = await getCurrentPosition();
    const ping = {
      id: crypto.randomUUID(),
      truck_id: document.getElementById("truckId").value.trim(),
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      speed_kmh: Number(document.getElementById("truckSpeed").value) || 0,
      cargo_weight_tons: Number(document.getElementById("truckCargo").value) || 0,
      status: "Active",
      updated_at: new Date().toISOString()
    };
    if (!navigator.onLine || !await sendPing(ping)) {
      await putOffline("pings", ping);
      status.textContent = "GPS ping queued for sync when the device reconnects.";
      scheduleBackgroundSync();
    } else {
      status.textContent = "Vehicle location shared with the live fleet map.";
      await refreshData();
    }
    await renderQueue();
  } catch (error) { status.textContent = error.message; }
}

async function sendPing(ping) {
  try {
    await api("/gps/ping", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(ping) });
    return true;
  } catch { return false; }
}

async function submitAlert(event) {
  event.preventDefault();
  const status = document.getElementById("alertStatus");
  const message = document.getElementById("alertMessage").value.trim();
  const language = document.getElementById("alertLanguage").value;
  try {
    const response = await api("/alerts/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: document.getElementById("alertTarget").value, severity: document.getElementById("alertSeverity").value, language, phone: document.getElementById("alertPhone").value.trim(), message })
    });
    speakAlert(message, language);
    status.textContent = `Alert recorded for ${response.alert.target}. ${response.alert.channel} · ${response.alert.delivery_status}.`;
    document.getElementById("alertMessage").value = "";
    await refreshData();
  } catch (error) { status.textContent = error.message; }
}

async function submitIncident(event) {
  event.preventDefault();
  const status = document.getElementById("incidentStatus");
  const payload = {
    title: document.getElementById("incidentTitle").value.trim(),
    assignee: document.getElementById("incidentAssignee").value.trim(),
    latitude: Number(document.getElementById("incidentLat").value),
    longitude: Number(document.getElementById("incidentLon").value),
    details: document.getElementById("incidentDetails").value.trim()
  };
  try {
    await api("/incidents", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    event.target.reset();
    status.textContent = "Incident assigned and added to the dispatch board.";
    await refreshData();
  } catch (error) { status.textContent = error.message; }
}

async function updateIncidentStatus(event) {
  const select = event.target.closest("[data-incident-id]");
  if (!select) return;
  try {
    await api(`/incidents/${encodeURIComponent(select.dataset.incidentId)}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: select.value })
    });
    await refreshData();
  } catch (error) { document.getElementById("incidentStatus").textContent = error.message; }
}

async function submitSafeSite(event) {
  event.preventDefault();
  const status = document.getElementById("siteStatus");
  const capacity = document.getElementById("siteCapacity").value;
  const payload = {
    name: document.getElementById("siteName").value.trim(),
    site_type: document.getElementById("siteType").value,
    latitude: Number(document.getElementById("siteLat").value),
    longitude: Number(document.getElementById("siteLon").value),
    capacity: capacity ? Number(capacity) : null,
    availability: document.getElementById("siteAvailability").value
  };
  try {
    await api("/safe-sites", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    event.target.reset();
    status.textContent = "Safe destination added.";
    await refreshData();
  } catch (error) { status.textContent = error.message; }
}

async function submitRoadStatus(event) {
  event.preventDefault();
  const status = document.getElementById("roadStatusMessage");
  const payload = {
    road_name: document.getElementById("roadStatusName").value.trim(),
    status: document.getElementById("roadStatusValue").value,
    latitude: Number(document.getElementById("roadStatusLat").value),
    longitude: Number(document.getElementById("roadStatusLon").value),
    notes: document.getElementById("roadStatusNotes").value.trim()
  };
  try {
    await api("/road-status", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    event.target.reset();
    status.textContent = "Road status saved and visible on the shared map.";
    await refreshData();
  } catch (error) { status.textContent = error.message; }
}

async function planEvacuation(event) {
  event.preventDefault();
  const status = document.getElementById("evacStatus");
  const results = document.getElementById("evacuationResults");
  const button = document.getElementById("evacButton");
  button.disabled = true;
  status.textContent = "Finding nearby open destinations and checking routes…";
  results.innerHTML = "";
  try {
    const origin = { lat: Number(document.getElementById("evacLat").value), lon: Number(document.getElementById("evacLon").value) };
    const siteData = await api("/safe-sites");
    const type = document.getElementById("evacType").value;
    const sites = (siteData.sites || []).filter(site => site.availability === "Open" && (!type || site.site_type === type))
      .map(site => ({ ...site, directDistance: distanceKm(origin.lat, origin.lon, Number(site.latitude), Number(site.longitude)) }))
      .sort((a, b) => a.directDistance - b.directDistance).slice(0, 5);
    if (!sites.length) throw new Error("No open destinations of that type are registered. Ask the control room to add verified sites.");
    const routeResults = await Promise.all(sites.map(async site => {
      const routeUrl = `https://router.project-osrm.org/route/v1/driving/${origin.lon},${origin.lat};${site.longitude},${site.latitude}?overview=full&geometries=geojson`;
      const response = await fetch(routeUrl);
      if (!response.ok) throw new Error("A route service request failed.");
      const data = await response.json();
      if (data.code !== "Ok" || !data.routes?.length) return { site, route: null, score: null };
      return { site, route: data.routes[0], score: null };
    }));
    const reachable = routeResults.filter(item => item.route);
    if (reachable.length) {
      const scoreData = await api("/route/score", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cargo_weight_tons: 0, priority: "Urgent", routes: reachable.map(item => ({ coordinates: sampleCoordinates(item.route.geometry.coordinates, 100) })) })
      });
      reachable.forEach((item, index) => { item.score = scoreData.routes[index]; });
    }
    routeResults.sort((a, b) => {
      if (!a.route) return 1;
      if (!b.route) return -1;
      return (a.score?.risk_score || 0) - (b.score?.risk_score || 0) || a.route.duration - b.route.duration;
    });
    results.innerHTML = routeResults.map(item => `<article class="record-card"><div><strong>${escapeHtml(item.site.name)} · ${escapeHtml(item.site.site_type)}</strong><p>${item.route ? `${(item.route.distance / 1000).toFixed(1)} km · ${formatDuration(item.route.duration)} · Route risk ${escapeHtml(item.score?.status || "Unknown")} (${escapeHtml(item.score?.risk_score ?? "—")}/100)` : "No driving route returned"}</p><small>${escapeHtml(item.site.availability)}${item.site.capacity === null ? "" : ` · Capacity ${escapeHtml(item.site.capacity)} people`}</small></div>${item.route ? `<button type="button" data-evac-route="${encodeURIComponent(JSON.stringify(item.route.geometry))}">Show route</button>` : ""}</article>`).join("");
    results.querySelectorAll("[data-evac-route]").forEach(routeButton => routeButton.addEventListener("click", () => {
      routeLayers.forEach(layer => map.removeLayer(layer));
      routeLayers = [L.geoJSON(JSON.parse(decodeURIComponent(routeButton.dataset.evacRoute)), { style: { color: "#187a58", weight: 7, opacity: 0.9 } }).addTo(map)];
      map.fitBounds(routeLayers[0].getBounds(), { padding: [25, 25] });
    }));
    status.textContent = `Checked ${sites.length} nearby open destination${sites.length === 1 ? "" : "s"}; routes are ranked by hazard risk, then driving time.`;
  } catch (error) {
    status.textContent = error.message || "Could not calculate evacuation options.";
    results.innerHTML = `<p class="record-empty">${escapeHtml(error.message)}</p>`;
  } finally { button.disabled = false; }
}

function distanceKm(lat1, lon1, lat2, lon2) {
  const radians = value => value * Math.PI / 180;
  const dLat = radians(lat2 - lat1), dLon = radians(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(radians(lat1)) * Math.cos(radians(lat2)) * Math.sin(dLon / 2) ** 2;
  return 6371.0088 * 2 * Math.asin(Math.sqrt(a));
}

function speakAlert(message, language) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(message);
  utterance.lang = language;
  utterance.rate = 0.92;
  window.speechSynthesis.speak(utterance);
}

async function fillCoordinates(latitudeId, longitudeId, statusId) {
  const status = document.getElementById(statusId);
  status.textContent = "Requesting GPS location…";
  try {
    const position = await getCurrentPosition();
    document.getElementById(latitudeId).value = position.coords.latitude.toFixed(6);
    document.getElementById(longitudeId).value = position.coords.longitude.toFixed(6);
    status.textContent = "Coordinates added from device GPS.";
  } catch (error) { status.textContent = error.message; }
}

function getCurrentPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) return reject(new Error("This device does not provide GPS location."));
    navigator.geolocation.getCurrentPosition(resolve, error => reject(new Error(error.message || "Could not read device location.")), { enableHighAccuracy: true, timeout: 15000, maximumAge: 15000 });
  });
}

async function loadWeatherWarnings() {
  const container = document.getElementById("weatherWarnings");
  container.innerHTML = '<p class="record-empty">Loading IMD district warnings…</p>';
  try {
    const data = await api("/weather/warnings");
    const warnings = flattenWarnings(data.warnings);
    if (!warnings.length) {
      container.innerHTML = '<p class="record-empty">No district warnings are listed in the latest IMD feed.</p>';
      return;
    }
    container.innerHTML = warnings.slice(0, 20).map(item => `<article class="record-card"><div><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.text)}</p></div><span class="severity-pill ${item.severity.toLowerCase()}">${escapeHtml(item.severity)}</span></article>`).join("");
  } catch (error) { container.innerHTML = `<p class="record-empty">${escapeHtml(error.message)}</p>`; }
}

function flattenWarnings(value) {
  let items = Array.isArray(value) ? value : Array.isArray(value?.warnings) ? value.warnings : Array.isArray(value?.data) ? value.data : [];
  if (!items.length && value && typeof value === "object") {
    items = Object.entries(value).filter(([, item]) => item && typeof item === "object").map(([name, item]) => ({ district_name: name, ...item }));
  }
  return items.map(item => {
    const text = String(item.warning || item.warning_desc || item.alert || item.description || item.message || item.color || "Weather warning");
    const place = String(item.district || item.district_name || item.districtName || item.name || item.state || "District alert");
    const severity = /red|extreme|very heavy|severe/i.test(text) ? "Critical" : /orange|heavy|moderate/i.test(text) ? "High" : "Moderate";
    return { title: place, text, severity };
  }).filter(item => item.text);
}

function sampleCoordinates(coordinates, maximum) {
  if (coordinates.length <= maximum) return coordinates;
  const stride = Math.ceil(coordinates.length / maximum);
  const sampled = coordinates.filter((_, index) => index % stride === 0);
  if (sampled[sampled.length - 1] !== coordinates[coordinates.length - 1]) sampled.push(coordinates[coordinates.length - 1]);
  return sampled;
}

function previewPhoto(event) {
  const preview = document.getElementById("photoPreview");
  const file = event.target.files[0];
  preview.replaceChildren();
  preview.hidden = !file;
  if (!file) return;
  const image = document.createElement("img");
  image.alt = "Selected report photo preview";
  image.src = URL.createObjectURL(file);
  preview.appendChild(image);
}

async function openOfflineDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("reports")) db.createObjectStore("reports", { keyPath: "id" });
      if (!db.objectStoreNames.contains("pings")) db.createObjectStore("pings", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Browser storage could not be opened."));
  });
}

async function putOffline(storeName, value) {
  const db = await openOfflineDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).put(value);
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}

async function allOffline(storeName) {
  const db = await openOfflineDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readonly");
    const request = transaction.objectStore(storeName).getAll();
    request.onsuccess = () => { db.close(); resolve(request.result); };
    request.onerror = () => { db.close(); reject(request.error); };
  });
}

async function removeOffline(storeName, key) {
  const db = await openOfflineDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).delete(key);
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}

async function renderQueue() {
  try {
    const [reports, pings] = await Promise.all([allOffline("reports"), allOffline("pings")]);
    const count = reports.length + pings.length;
    document.getElementById("queueCount").textContent = `${count} item${count === 1 ? "" : "s"} pending`;
    const list = document.getElementById("queueList");
    const entries = [
      ...reports.map(item => ({ kind: "Field report", label: `${item.report_type} · ${item.location || "Geo-tagged"}`, time: item.created_at })),
      ...pings.map(item => ({ kind: "GPS ping", label: item.truck_id, time: item.updated_at }))
    ];
    list.innerHTML = entries.length ? entries.map(item => `<article class="record-card"><div><strong>${escapeHtml(item.kind)} · ${escapeHtml(item.label)}</strong><small>Queued ${new Date(item.time).toLocaleString()}</small></div><span class="draft-state">Waiting to sync</span></article>`).join("") : '<p class="record-empty">All reports and vehicle pings are synced.</p>';
  } catch (error) {
    document.getElementById("queueList").innerHTML = `<p class="record-empty">${escapeHtml(error.message)}</p>`;
  }
}

async function syncOfflineQueue() {
  if (!navigator.onLine) { await renderQueue(); return; }
  try {
    const reports = await allOffline("reports");
    for (const report of reports) {
      if (await sendReport(report)) await removeOffline("reports", report.id);
    }
    const pings = await allOffline("pings");
    if (pings.length) {
      try {
        await api("/sync", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pings }) });
        for (const ping of pings) await removeOffline("pings", ping.id);
      } catch { /* Keep failed pings queued for another attempt. */ }
    }
    await renderQueue();
    await refreshData();
  } catch (error) { console.error("Offline sync failed:", error); }
}

async function scheduleBackgroundSync() {
  try {
    const registration = await navigator.serviceWorker?.ready;
    if (registration?.sync) await registration.sync.register("resiliroute-offline-sync");
  } catch { /* Online event and the manual sync control remain available. */ }
}

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  try { await navigator.serviceWorker.register("/resiliroute-sw.js"); }
  catch (error) { console.info("Offline app shell registration unavailable:", error); }
}

function updateConnectivity() {
  const pill = document.getElementById("connectivityStatus");
  pill.classList.toggle("offline", !navigator.onLine);
  pill.textContent = navigator.onLine ? "Online · live sync" : "Offline · local capture enabled";
}

function severityColor(severity) {
  return ({ Critical: "#9e2331", High: "#db5740", Moderate: "#e4a23a", Low: "#58a879" })[severity] || "#6d8294";
}

function formatDuration(seconds) {
  const minutes = Math.round(seconds / 60);
  const hours = Math.floor(minutes / 60);
  return hours ? `${hours} hr ${minutes % 60} min` : `${minutes} min`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
