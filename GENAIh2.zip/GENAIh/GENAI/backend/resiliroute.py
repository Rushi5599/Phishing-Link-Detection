import base64
import json
import math
import os
import re
import sqlite3
import urllib.error
import urllib.parse
import urllib.request
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

from flask import Blueprint, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename


bp = Blueprint("resiliroute", __name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "resiliroute.sqlite3")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads", "reports")
MAX_REPORT_PHOTO_BYTES = 8 * 1024 * 1024
ALLOWED_PHOTO_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}
_warning_cache = {"expires": 0, "data": None}


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def get_db():
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


@contextmanager
def database():
    connection = get_db()
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def init_storage():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with database() as connection:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS hazards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                hazard_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                road_name TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                bridge_limit_tons REAL,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS field_reports (
                id TEXT PRIMARY KEY,
                report_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                location TEXT NOT NULL DEFAULT '',
                notes TEXT NOT NULL DEFAULT '',
                photo_filename TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS fleet_pings (
                truck_id TEXT PRIMARY KEY,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                speed_kmh REAL NOT NULL DEFAULT 0,
                cargo_weight_tons REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'Active',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS alerts (
                id TEXT PRIMARY KEY,
                target TEXT NOT NULL,
                language TEXT NOT NULL,
                severity TEXT NOT NULL,
                message TEXT NOT NULL,
                channel TEXT NOT NULL,
                delivery_status TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS incidents (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                assignee TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Assigned',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS road_status_updates (
                id TEXT PRIMARY KEY,
                road_name TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS safe_sites (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                site_type TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                capacity INTEGER,
                availability TEXT NOT NULL DEFAULT 'Open',
                created_at TEXT NOT NULL
            );
        """)


init_storage()


def json_error(message, status=400):
    return jsonify({"error": message}), status


def parse_coordinate(value, minimum, maximum):
    try:
        coordinate = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(coordinate) or not minimum <= coordinate <= maximum:
        return None
    return coordinate


def as_dict(row):
    return dict(row) if row is not None else None


def get_hazards(connection=None):
    owns_connection = connection is None
    connection = connection or get_db()
    try:
        return [dict(row) for row in connection.execute(
            "SELECT * FROM hazards WHERE active = 1 ORDER BY created_at DESC"
        ).fetchall()]
    finally:
        if owns_connection:
            connection.close()


def get_blocked_roads():
    with database() as connection:
        rows = connection.execute("SELECT * FROM road_status_updates WHERE status = 'Blocked'").fetchall()
    return [{
        "id": f"road-{row['id']}", "title": row["road_name"] or "Blocked road",
        "severity": "Critical", "latitude": row["latitude"], "longitude": row["longitude"],
        "hazard_type": "Road closure", "bridge_limit_tons": None
    } for row in rows]


def haversine_km(lat1, lon1, lat2, lon2):
    radius = 6371.0088
    lat1, lon1, lat2, lon2 = map(math.radians, (lat1, lon1, lat2, lon2))
    delta_lat, delta_lon = lat2 - lat1, lon2 - lon1
    value = math.sin(delta_lat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(delta_lon / 2) ** 2
    return 2 * radius * math.asin(math.sqrt(value))


def report_payload(data, photo_filename=""):
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    report_type = str(data.get("report_type", "")).strip()[:80]
    severity = str(data.get("severity", "Moderate")).strip().title()
    if latitude is None or longitude is None or not report_type:
        return None, "A report type and valid coordinates are required."
    if severity not in {"Low", "Moderate", "High", "Critical"}:
        return None, "Severity must be Low, Moderate, High, or Critical."
    return {
        "id": str(data.get("id") or uuid.uuid4()),
        "report_type": report_type,
        "severity": severity,
        "latitude": latitude,
        "longitude": longitude,
        "location": str(data.get("location", "")).strip()[:200],
        "notes": str(data.get("notes", "")).strip()[:2000],
        "photo_filename": photo_filename,
        "created_at": str(data.get("created_at") or utc_now())[:40],
    }, None


def insert_report(data, photo_filename=""):
    report, error = report_payload(data, photo_filename)
    if error:
        return None, error
    with database() as connection:
        cursor = connection.execute("""
            INSERT OR IGNORE INTO field_reports
            (id, report_type, severity, latitude, longitude, location, notes, photo_filename, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, tuple(report[key] for key in (
            "id", "report_type", "severity", "latitude", "longitude", "location", "notes", "photo_filename", "created_at"
        )))
        lowered_type = report["report_type"].lower()
        if cursor.rowcount and any(word in lowered_type for word in ("landslide", "flood", "blocked", "closure", "bridge", "accident", "road damage")):
            connection.execute("""
                INSERT INTO hazards (title, hazard_type, severity, latitude, longitude, road_name, description, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                f"Field report: {report['report_type']}", report["report_type"], report["severity"],
                report["latitude"], report["longitude"], report["location"], report["notes"], report["created_at"]
            ))
        saved = connection.execute("SELECT * FROM field_reports WHERE id = ?", (report["id"],)).fetchone()
    return dict(saved), None


def insert_ping(data):
    truck_id = str(data.get("truck_id", "")).strip()[:100]
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    speed = parse_coordinate(data.get("speed_kmh", 0), 0, 400)
    cargo = parse_coordinate(data.get("cargo_weight_tons", 0), 0, 1000)
    if not truck_id or latitude is None or longitude is None or speed is None or cargo is None:
        return None, "A truck ID and valid GPS, speed, and cargo values are required."
    status = str(data.get("status", "Active")).strip().title()
    if status not in {"Active", "Idle", "Emergency"}:
        status = "Active"
    ping = (truck_id, latitude, longitude, speed, cargo, status, str(data.get("updated_at") or utc_now())[:40])
    with database() as connection:
        connection.execute("""
            INSERT INTO fleet_pings (truck_id, latitude, longitude, speed_kmh, cargo_weight_tons, status, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(truck_id) DO UPDATE SET
            latitude=excluded.latitude, longitude=excluded.longitude, speed_kmh=excluded.speed_kmh,
            cargo_weight_tons=excluded.cargo_weight_tons, status=excluded.status, updated_at=excluded.updated_at
        """, ping)
        saved = connection.execute("SELECT * FROM fleet_pings WHERE truck_id = ?", (truck_id,)).fetchone()
    return dict(saved), None


@bp.get("/api/resiliroute/overview")
def overview():
    with database() as connection:
        counts = {
            "active_hazards": connection.execute("SELECT COUNT(*) FROM hazards WHERE active = 1").fetchone()[0],
            "field_reports": connection.execute("SELECT COUNT(*) FROM field_reports").fetchone()[0],
            "tracked_trucks": connection.execute("SELECT COUNT(*) FROM fleet_pings").fetchone()[0],
            "alerts_sent": connection.execute("SELECT COUNT(*) FROM alerts").fetchone()[0],
        }
        latest_alerts = [dict(row) for row in connection.execute(
            "SELECT * FROM alerts ORDER BY created_at DESC LIMIT 5"
        ).fetchall()]
    return jsonify({"counts": counts, "latest_alerts": latest_alerts})


@bp.get("/api/resiliroute/hazards")
def list_hazards():
    return jsonify({"hazards": get_hazards()})


@bp.post("/api/resiliroute/hazards")
def create_hazard():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()[:120]
    hazard_type = str(data.get("hazard_type", "")).strip()[:60]
    severity = str(data.get("severity", "")).strip().title()
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    if not title or not hazard_type or severity not in {"Low", "Moderate", "High", "Critical"} or latitude is None or longitude is None:
        return json_error("Title, type, severity, and valid coordinates are required.")

    bridge_limit = data.get("bridge_limit_tons")
    if bridge_limit in (None, ""):
        bridge_limit = None
    else:
        bridge_limit = parse_coordinate(bridge_limit, 0, 1000)
        if bridge_limit is None:
            return json_error("Bridge weight limit must be between 0 and 1000 tonnes.")

    with database() as connection:
        cursor = connection.execute("""
            INSERT INTO hazards (title, hazard_type, severity, latitude, longitude, road_name, description, bridge_limit_tons, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            title, hazard_type, severity, latitude, longitude,
            str(data.get("road_name", "")).strip()[:120],
            str(data.get("description", "")).strip()[:1000],
            bridge_limit, utc_now()
        ))
        hazard = as_dict(connection.execute("SELECT * FROM hazards WHERE id = ?", (cursor.lastrowid,)).fetchone())
    return jsonify({"hazard": hazard}), 201


@bp.delete("/api/resiliroute/hazards/<int:hazard_id>")
def close_hazard(hazard_id):
    with database() as connection:
        cursor = connection.execute("UPDATE hazards SET active = 0 WHERE id = ?", (hazard_id,))
    if not cursor.rowcount:
        return json_error("Hazard was not found.", 404)
    return jsonify({"closed": True, "id": hazard_id})


@bp.get("/api/resiliroute/reports")
def list_reports():
    with database() as connection:
        reports = [dict(row) for row in connection.execute(
            "SELECT * FROM field_reports ORDER BY created_at DESC LIMIT 100"
        ).fetchall()]
    for report in reports:
        report["photo_url"] = f"/api/resiliroute/uploads/{report['photo_filename']}" if report["photo_filename"] else ""
    return jsonify({"reports": reports})


@bp.post("/api/resiliroute/reports")
def create_report():
    data = request.form.to_dict() if request.form else (request.get_json(silent=True) or {})
    photo = request.files.get("photo")
    filename = ""
    if photo and photo.filename:
        safe_name = secure_filename(photo.filename)
        extension = safe_name.rsplit(".", 1)[-1].lower() if "." in safe_name else ""
        if extension not in ALLOWED_PHOTO_EXTENSIONS:
            return json_error("Choose a JPG, PNG, or WebP image.")
        content = photo.stream.read(MAX_REPORT_PHOTO_BYTES + 1)
        if len(content) > MAX_REPORT_PHOTO_BYTES:
            return json_error("Report photos must be 8 MB or smaller.")
        if not content.startswith((b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n", b"RIFF")):
            return json_error("The uploaded file is not a supported image.")
        filename = f"{uuid.uuid4().hex}.{extension}"
        with open(os.path.join(UPLOAD_DIR, filename), "wb") as image_file:
            image_file.write(content)

    report, error = insert_report(data, filename)
    if error:
        if filename:
            try:
                os.remove(os.path.join(UPLOAD_DIR, filename))
            except OSError:
                pass
        return json_error(error)
    report["photo_url"] = f"/api/resiliroute/uploads/{filename}" if filename else ""
    return jsonify({"report": report}), 201


@bp.get("/api/resiliroute/uploads/<path:filename>")
def report_photo(filename):
    return send_from_directory(UPLOAD_DIR, filename, max_age=3600)


@bp.get("/api/resiliroute/fleet")
def list_fleet():
    with database() as connection:
        fleet = [dict(row) for row in connection.execute(
            "SELECT * FROM fleet_pings ORDER BY updated_at DESC"
        ).fetchall()]
    return jsonify({"fleet": fleet})


@bp.post("/api/resiliroute/gps/ping")
def gps_ping():
    ping, error = insert_ping(request.get_json(silent=True) or {})
    if error:
        return json_error(error)
    return jsonify({"ping": ping}), 201


@bp.post("/api/resiliroute/sync")
def offline_sync():
    data = request.get_json(silent=True) or {}
    reports = data.get("reports", [])
    pings = data.get("pings", [])
    if not isinstance(reports, list) or not isinstance(pings, list) or len(reports) + len(pings) > 100:
        return json_error("Sync accepts up to 100 reports and GPS pings at a time.")
    synced_reports, synced_pings, errors = [], [], []
    for item in reports:
        if not isinstance(item, dict):
            errors.append("Skipped a malformed report.")
            continue
        report, error = insert_report(item)
        if error:
            errors.append(error)
        elif report:
            synced_reports.append(report["id"])
    for item in pings:
        if not isinstance(item, dict):
            errors.append("Skipped a malformed GPS ping.")
            continue
        ping, error = insert_ping(item)
        if error:
            errors.append(error)
        elif ping:
            synced_pings.append(ping["truck_id"])
    return jsonify({"synced_reports": synced_reports, "synced_pings": synced_pings, "errors": errors})


@bp.get("/api/resiliroute/incidents")
def list_incidents():
    with database() as connection:
        incidents = [dict(row) for row in connection.execute(
            "SELECT * FROM incidents ORDER BY CASE status WHEN 'Assigned' THEN 0 WHEN 'In progress' THEN 1 ELSE 2 END, updated_at DESC LIMIT 100"
        ).fetchall()]
    return jsonify({"incidents": incidents})


@bp.post("/api/resiliroute/incidents")
def create_incident():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()[:160]
    assignee = str(data.get("assignee", "")).strip()[:120]
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    if not title or not assignee or latitude is None or longitude is None:
        return json_error("Incident title, assignee, and valid coordinates are required.")
    incident = {
        "id": str(uuid.uuid4()), "title": title,
        "details": str(data.get("details", "")).strip()[:1000],
        "latitude": latitude, "longitude": longitude, "assignee": assignee,
        "status": "Assigned", "created_at": utc_now(), "updated_at": utc_now()
    }
    with database() as connection:
        connection.execute("""INSERT INTO incidents
            (id, title, details, latitude, longitude, assignee, status, created_at, updated_at)
            VALUES (:id, :title, :details, :latitude, :longitude, :assignee, :status, :created_at, :updated_at)""", incident)
    return jsonify({"incident": incident}), 201


@bp.patch("/api/resiliroute/incidents/<incident_id>")
def update_incident(incident_id):
    data = request.get_json(silent=True) or {}
    requested_status = str(data.get("status", "")).strip().lower()
    status = {"assigned": "Assigned", "in progress": "In progress", "resolved": "Resolved"}.get(requested_status, "")
    if status not in {"Assigned", "In progress", "Resolved"}:
        return json_error("Status must be Assigned, In progress, or Resolved.")
    with database() as connection:
        cursor = connection.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?", (status, utc_now(), incident_id))
        row = connection.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
    if not cursor.rowcount:
        return json_error("Incident was not found.", 404)
    return jsonify({"incident": dict(row)})


@bp.get("/api/resiliroute/road-status")
def list_road_status():
    with database() as connection:
        updates = [dict(row) for row in connection.execute("SELECT * FROM road_status_updates ORDER BY updated_at DESC LIMIT 100").fetchall()]
    return jsonify({"updates": updates})


@bp.post("/api/resiliroute/road-status")
def create_road_status():
    data = request.get_json(silent=True) or {}
    status = str(data.get("status", "")).strip().title()
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    road_name = str(data.get("road_name", "")).strip()[:160]
    if status not in {"Open", "Blocked", "Cleared"} or latitude is None or longitude is None:
        return json_error("Choose a road status and provide valid coordinates.")
    update = {"id": str(uuid.uuid4()), "road_name": road_name, "status": status,
              "latitude": latitude, "longitude": longitude, "notes": str(data.get("notes", "")).strip()[:1000], "updated_at": utc_now()}
    with database() as connection:
        if road_name:
            connection.execute("UPDATE road_status_updates SET status = 'Cleared' WHERE lower(road_name) = lower(?) AND status = 'Blocked'", (road_name,))
        connection.execute("""INSERT INTO road_status_updates (id, road_name, status, latitude, longitude, notes, updated_at)
            VALUES (:id, :road_name, :status, :latitude, :longitude, :notes, :updated_at)""", update)
    return jsonify({"update": update}), 201


@bp.get("/api/resiliroute/safe-sites")
def list_safe_sites():
    with database() as connection:
        sites = [dict(row) for row in connection.execute("SELECT * FROM safe_sites ORDER BY name COLLATE NOCASE").fetchall()]
    return jsonify({"sites": sites})


@bp.post("/api/resiliroute/safe-sites")
def create_safe_site():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()[:160]
    site_type = str(data.get("site_type", "")).strip().title()
    latitude = parse_coordinate(data.get("latitude"), -90, 90)
    longitude = parse_coordinate(data.get("longitude"), -180, 180)
    capacity_value = data.get("capacity")
    capacity = None if capacity_value in (None, "") else parse_coordinate(capacity_value, 0, 1000000)
    availability = str(data.get("availability", "Open")).strip().title()
    if not name or site_type not in {"Shelter", "Hospital", "Relief center"} or latitude is None or longitude is None or (capacity_value not in (None, "") and capacity is None) or availability not in {"Open", "Full", "Closed"}:
        return json_error("Provide a name, site type, valid coordinates, capacity, and availability.")
    site = {"id": str(uuid.uuid4()), "name": name, "site_type": site_type, "latitude": latitude,
            "longitude": longitude, "capacity": int(capacity) if capacity is not None else None,
            "availability": availability, "created_at": utc_now()}
    with database() as connection:
        connection.execute("""INSERT INTO safe_sites (id, name, site_type, latitude, longitude, capacity, availability, created_at)
            VALUES (:id, :name, :site_type, :latitude, :longitude, :capacity, :availability, :created_at)""", site)
    return jsonify({"site": site}), 201


@bp.get("/api/resiliroute/fleet/nearby-alerts")
def nearby_driver_alerts():
    truck_id = str(request.args.get("truck_id", "")).strip()[:100]
    if not truck_id:
        return json_error("A vehicle ID is required.")
    with database() as connection:
        ping = connection.execute("SELECT * FROM fleet_pings WHERE truck_id = ?", (truck_id,)).fetchone()
    if not ping:
        return jsonify({"truck_id": truck_id, "alerts": []})
    alerts = []
    for hazard in get_hazards() + get_blocked_roads():
        distance = haversine_km(ping["latitude"], ping["longitude"], hazard["latitude"], hazard["longitude"])
        if distance <= 10:
            alerts.append({"id": hazard["id"], "title": hazard["title"], "severity": hazard["severity"], "distance_km": round(distance, 1), "latitude": hazard["latitude"], "longitude": hazard["longitude"]})
    return jsonify({"truck_id": truck_id, "alerts": sorted(alerts, key=lambda item: item["distance_km"])})


@bp.post("/api/resiliroute/route/score")
def score_route_alternatives():
    data = request.get_json(silent=True) or {}
    candidates = data.get("routes")
    cargo = parse_coordinate(data.get("cargo_weight_tons", 0), 0, 1000)
    priority = str(data.get("priority", "Standard")).title()
    if not isinstance(candidates, list) or not candidates or len(candidates) > 5 or cargo is None:
        return json_error("Provide up to five route alternatives and a valid cargo weight.")
    hazards = get_hazards() + get_blocked_roads()
    scored = []
    for index, candidate in enumerate(candidates):
        points = candidate.get("coordinates") if isinstance(candidate, dict) else None
        if not isinstance(points, list) or not points:
            return json_error("Each route needs GeoJSON coordinates.")
        stride = max(1, math.ceil(len(points) / 120))
        sampled_points = points[::stride]
        if points[-1] != sampled_points[-1]:
            sampled_points.append(points[-1])
        risk = 0.0
        nearby, restrictions = {}, []
        valid_points = []
        for point in sampled_points:
            if not isinstance(point, list) or len(point) < 2:
                continue
            lon, lat = parse_coordinate(point[0], -180, 180), parse_coordinate(point[1], -90, 90)
            if lat is not None and lon is not None:
                valid_points.append((lat, lon))
        for hazard in hazards:
            distance = min((haversine_km(lat, lon, hazard["latitude"], hazard["longitude"]) for lat, lon in valid_points), default=math.inf)
            if distance > 10:
                continue
            severity_weight = {"Low": 5, "Moderate": 12, "High": 25, "Critical": 40}.get(hazard["severity"], 8)
            risk += severity_weight * max(0, 1 - distance / 10)
            nearby[hazard["id"]] = {"id": hazard["id"], "title": hazard["title"], "severity": hazard["severity"], "distance_km": round(distance, 1)}
            bridge_limit = hazard["bridge_limit_tons"]
            if bridge_limit is not None and distance <= 1.5 and cargo > bridge_limit:
                risk += 100
                restrictions.append({"hazard_id": hazard["id"], "title": hazard["title"], "limit_tons": bridge_limit, "cargo_weight_tons": cargo})
        if priority == "Urgent":
            risk *= 0.9
        scored.append({
            "index": index,
            "risk_score": round(min(100, risk), 1),
            "nearby_hazards": list(nearby.values()),
            "bridge_restrictions": restrictions,
            "status": "Avoid" if risk >= 55 or restrictions else ("Caution" if risk >= 18 else "Clear"),
        })
    return jsonify({"routes": scored, "risk_method": "hazard proximity and bridge load rules"})


@bp.get("/api/resiliroute/risk/predict")
def predict_risk():
    latitude = parse_coordinate(request.args.get("latitude"), -90, 90)
    longitude = parse_coordinate(request.args.get("longitude"), -180, 180)
    if latitude is None or longitude is None:
        return json_error("Valid latitude and longitude are required.")
    nearby = []
    score = 0
    for hazard in get_hazards() + get_blocked_roads():
        distance = haversine_km(latitude, longitude, hazard["latitude"], hazard["longitude"])
        if distance <= 25:
            weight = {"Low": 5, "Moderate": 12, "High": 25, "Critical": 40}.get(hazard["severity"], 8)
            score += weight * max(0, 1 - distance / 25)
            nearby.append({"id": hazard["id"], "title": hazard["title"], "severity": hazard["severity"], "distance_km": round(distance, 1)})
    score = round(min(100, score), 1)
    return jsonify({"risk_score": score, "risk_level": "High" if score >= 55 else "Moderate" if score >= 18 else "Low", "nearby_hazards": nearby})


@bp.get("/api/resiliroute/weather/warnings")
def weather_warnings():
    now = datetime.now(timezone.utc).timestamp()
    if _warning_cache["data"] is not None and _warning_cache["expires"] > now:
        return jsonify({"warnings": _warning_cache["data"], "cached": True})
    url = "https://mausam.imd.gov.in/api/warnings_district_api.php"
    try:
        request_obj = urllib.request.Request(url, headers={"User-Agent": "ResiliRoute/1.0"})
        with urllib.request.urlopen(request_obj, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        _warning_cache.update({"data": payload, "expires": now + 300})
        return jsonify({"warnings": payload, "cached": False})
    except (urllib.error.URLError, TimeoutError, ValueError):
        if _warning_cache["data"] is not None:
            return jsonify({"warnings": _warning_cache["data"], "cached": True})
        return jsonify({"warnings": [], "cached": False, "error": "IMD warnings are temporarily unavailable."}), 502


@bp.get("/api/resiliroute/alerts")
def list_alerts():
    with database() as connection:
        alerts = [dict(row) for row in connection.execute("SELECT * FROM alerts ORDER BY created_at DESC LIMIT 50").fetchall()]
    return jsonify({"alerts": alerts})


@bp.post("/api/resiliroute/alerts/send")
def send_alert():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()[:1000]
    target = str(data.get("target", "All field teams")).strip()[:120]
    language = str(data.get("language", "en-IN"))[:16]
    severity = str(data.get("severity", "High")).strip().title()
    phone = str(data.get("phone", "")).strip()
    if not message:
        return json_error("Alert message is required.")
    channel = "dashboard and voice"
    delivery_status = "recorded"
    account_sid = os.environ.get("TWILIO_ACCOUNT_SID", "")
    auth_token = os.environ.get("TWILIO_AUTH_TOKEN", "")
    from_number = os.environ.get("TWILIO_FROM_NUMBER", "")
    if phone and account_sid and auth_token and from_number and re.fullmatch(r"\+[1-9]\d{7,14}", phone):
        endpoint = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
        form = urllib.parse.urlencode({"To": phone, "From": from_number, "Body": message}).encode("utf-8")
        auth = base64.b64encode(f"{account_sid}:{auth_token}".encode("utf-8")).decode("ascii")
        req = urllib.request.Request(endpoint, data=form, headers={"Authorization": f"Basic {auth}", "Content-Type": "application/x-www-form-urlencoded"})
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                delivery_status = "sent" if response.status < 300 else "failed"
            channel = "SMS, dashboard, and voice"
        except urllib.error.URLError:
            delivery_status = "failed"
            channel = "dashboard and voice"

    alert = {"id": str(uuid.uuid4()), "target": target, "language": language, "severity": severity, "message": message, "channel": channel, "delivery_status": delivery_status, "created_at": utc_now()}
    with database() as connection:
        connection.execute("""
            INSERT INTO alerts (id, target, language, severity, message, channel, delivery_status, created_at)
            VALUES (:id, :target, :language, :severity, :message, :channel, :delivery_status, :created_at)
        """, alert)
    return jsonify({"alert": alert}), 201
